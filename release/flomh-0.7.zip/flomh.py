import os
import re
import sys
import json
import struct
import subprocess
import urllib.parse

version = '0.7'

def get_message():
    blen = sys.stdin.buffer.read(4)
    if len(blen) == 0:
        sys.exit(0)
    slen = struct.unpack('@I', blen)[0]
    return sys.stdin.buffer.read(slen).decode('utf-8')

def send_message(content):
    encoded_content = json.dumps(content, separators=(',', ':')).encode('utf-8')
    blen = struct.pack('@I', len(encoded_content))
    sys.stdout.buffer.write(blen)
    sys.stdout.buffer.write(encoded_content)
    sys.stdout.buffer.flush()

msg = json.loads(get_message())

#------------------------------------------------------------------------------

# get Options
if msg['request'] == 'O':
    if os.path.exists('options.json'):
        with open('options.json', mode='rt', encoding='utf-8') as f:
            send_message({'response': re.sub('^\s*|\s*\n+\s*', '', f.read())})
    else:
        send_message({'response': 'NF'}) # Not Found

#------------------------------------------------------------------------------

# open Path
elif msg['request'] == 'P':
    
    # Launch parameters
    opt = int(msg['opt'])
    
    # Path (decode, remove "file:///" and turn slashes)
    path = urllib.parse.unquote(msg['path'])[8:].replace('/', '\\')
    
    # Check the file or folder existence
    if os.path.exists(path):
        cmd = 'explorer.exe '
        if opt & 0x01:
            cmd += '/select, '
        cmd += '"' + path + '"'
        subprocess.run(cmd)
        send_message({'response': 'OK'})
    else:
        send_message({'response': 'NF'}) # Not Found

#------------------------------------------------------------------------------

# get Version
elif msg['request'] == 'V':
    send_message({'response': version})

#------------------------------------------------------------------------------

# unknown request
else:
    send_message({'response': 'UR'}) # Unknown Request
